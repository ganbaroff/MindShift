# MindFlow — Claude Code Memory

> ADHD productivity OS · React + Vite + Supabase + Gemini · EN/RU/AZ

---

## Stack & Repo

```
Repo:     https://github.com/ganbaroff/MingFocusClaude
Deploy:   Vercel (auto-deploy on push to main)
Dev:      npm run dev  (Vite, port 5173)
Build:    npm run build
Preview:  npm run preview
```

```
React 18 · TypeScript · Vite · Zustand
Supabase (Auth + Postgres + Realtime)
Gemini 2.0 Flash (AI parse, reflection, focus)
vite-plugin-pwa (service worker, offline)
```

---

## Project Structure

```
src/
├── app/          # App.tsx, router, Zustand store
├── features/     # dump/ today/ evening/ settings/ auth/
│   └── [name]/   # Screen.tsx + use[Name].ts + types.ts
├── services/     # supabase.ts · gemini.ts · sync.ts
├── components/   # ThoughtCard/ BottomNav/ ui/
├── hooks/        # useThoughts · useStreak · useOffline
├── constants/    # colors.ts · i18n.ts · types.ts
└── workers/      # service-worker.ts
```

---

## Supabase

```
URL:  https://pvzsxbyocmtjtbntilyh.supabase.co
Key:  sb_publishable_7EN4as2jUeNDrPfweWEYyQ_LYmLf3I8 (anon/publishable only)
```

**NEVER use sb_secret_* key in client code.**  
**NEVER commit .env.local to git.**

Session identity: `localStorage.getItem("mf_session")` — UUID per device, no auth required for MVP.

For DB schema and RLS rules → see `docs/supabase-rules.md`

---

## AI (Gemini)

```
Key:    AIzaSyDYT68Kkb5Xa1Y050-CCiJ1PPhHFXdPPAc
Model:  gemini-2.0-flash
```

For prompt patterns and response schemas → see `docs/ai-prompts.md`

---

## Design System

Single source of truth: `src/constants/colors.ts` — the `C` object.  
For full UI rules, component patterns, SVG icons → see `.claude/skills/mindflow-ui/SKILL.md`

**Rules Claude must always follow:**
- NO emoji as icons — SVG only (Lucide or custom inline)
- Touch targets ≥ 44×44px always
- WCAG AA contrast on all text (verified in C object)
- `cursor: pointer` on all interactive elements

---

## Thought Type System

```typescript
type ThoughtType = "task" | "idea" | "note" | "reminder" | "expense" | "memory"
type Priority    = "none" | "low" | "medium" | "high" | "critical"
```

---

## Languages

EN (default) · RU · AZ  
i18n key: `localStorage.getItem("mf_lang")`  
All user-facing strings go in `src/constants/i18n.ts` — never hardcode.

---

## Payments (future)

Local Azerbaijani payment providers: **M10**, **AzeriCard**  
Do NOT implement Stripe.  
For integration specs → see `docs/payments-az.md` (create when ready)

---

## What Claude often gets wrong in this project

1. **Using emoji as icons** — always use SVG from the `Ico` object in `colors.ts`
2. **Hardcoding strings** — all text must go through `T[lang]` i18n
3. **Using secret Supabase key** — only publishable key in client
4. **Forgetting cursor: pointer** — add to every button and clickable element
5. **Font in textarea** — must be `fontFamily: "inherit"` or `'Satoshi'`
6. **Body text < 16px** — minimum 16px for mobile readability

---

## Git Conventions

```bash
feat: add voice input to DumpScreen
fix: correct streak calculation for timezone edge case  
chore: update Supabase types
refactor: extract useThoughts hook from App.tsx
```

Branch naming: `feat/subtasks` · `fix/streak-bug` · `chore/ts-migration`

---

## Current Sprint (update this section after each session)

**Sprint 6 — Active**
- [x] v4 redesign (Neural Paper → Deep Void dark)  
- [x] Real Gemini AI integration  
- [x] Real Supabase persistence  
- [ ] TypeScript migration  
- [ ] Split monolith into /features architecture  
- [ ] PWA (vite-plugin-pwa + service worker)  
- [ ] Vitest unit tests (AI parse, streak logic)  
- [ ] M10/AzeriCard payment research  

---

## Session Log

For full history → `journal.txt` in project root  
After each session: update Sprint section above + append to journal.txt
